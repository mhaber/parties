README.TXT
CSES Module 1 - August 04, 2003 release

-----

The ZIP file "csesmod1.zip" contains eight (8) files relating to
the August 04, 2002 release of the Comparative Study of Electoral 
Systems (CSES) Module 1 Merged Micro-District-Macro Data File

The files are:
   
   "cm1_cod1.txt" the codebook introduction file
   "cm1_cod2.txt" the codebook variable descriptions file
   "cm1_cod3.txt" the codebook appendices file

   "cm1_dat.txt"  the raw data file

   "readme.txt"   this file
   
   "sas.zip"      statements for reading the data into SAS
   "spss.zip"     statements for reading the data into SPSS
   "stata.zip"    statements for reading the data into STATA

Users are encouraged to become familiar with the codebook (particularly
the introduction file) prior to proceeding with analysis.

-----

The files released on August 04, 2003 are an update to the original 
release of July 26, 2002.  The updated files are being provided as
a convenience to users.  No records were removed nor added, and so
the record, country, and election study count remain the same.  

Updates were as follows:

1. Some minor codebook and label corrections (usually typographical 
errors or small improvements) were made.

2. All errata posted on the website from July 26, 2002 through 
August 4, 2003 were applied to the files.  

3. Variable "A1007", previously containing "OLD POLITY CODE" data,
was replaced with data concerning "SAMPLE COMPONENT".  The new use 
of variable "A1007" for "SAMPLE COMPONENT" allows us to identify 
regions of countries or other sample components as units of 
analysis, rather than the elections themselves. 

"OLD POLITY CODE" was a past CSES identification variable that 
is now outdated (having been replaced by variable "A1006", 
"ID COMPONENT - POLITY", which is based on United Nations 
Statistics Division coding schemes).

-----

Additional information about the CSES, including continuously updated
and past errata for CSES Module 1, can be found on the CSES web site at:

    http://www.umich.edu/~cses
    
Users with questions can send an e-mail to the CSES help desk at:

    cses@umich.edu
    
Thank you for your support of the CSES!